class User:

    def __init__(self, firstname, lastname):
        self.firstname = firstname
        self.lastname = lastname

    def getFirstName(self):
        return self.firstname

    def getLastName(self):
        return self.lastname
